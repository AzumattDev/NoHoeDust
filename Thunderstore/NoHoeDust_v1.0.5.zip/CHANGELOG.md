| `Version` | `Update Notes`                                                                                                            |
|-----------|---------------------------------------------------------------------------------------------------------------------------|
| 1.0.5     | - Courtesy Update for Valheim 0.217.46. Just bumping the version and updating the last updated date. Nothing to see here. |
| 1.0.4     | - Update for Valheim 0.217.22                                                                                             |
| 1.0.3     | - Fix issue with OdinCampsite (probably other things too)                                                                 |
| 1.0.2     | - Set priorities to hopefully make this work with more mods that might be doing things later.                             |
| 1.0.1     | - Forgot to exclude paths.                                                                                                |
| 1.0.0     | - Initial Release                                                                                                         |